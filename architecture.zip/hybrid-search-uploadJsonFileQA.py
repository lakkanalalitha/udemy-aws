import streamlit as st
import time
import os
import json
from langchain_groq import ChatGroq
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain.prompts import ChatPromptTemplate
from langchain.chains import create_retrieval_chain
from langchain.vectorstores import FAISS
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain.docstore.document import Document
from langchain.retrievers import EnsembleRetriever
from langchain_community.retrievers import BM25Retriever



# Load the GROQ and Google API keys
google_api_key = "AIzaSyApvKUpUh1_AKiToNVnz9Rup_Sx56S8vjU"
groq_api_key = "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"

st.title("Patent Json Document(s) Q&A")

# Llama3 model
llm = ChatGroq(groq_api_key=groq_api_key, model_name="Llama3-8b-8192")

prompt = ChatPromptTemplate.from_template(
    """
    Answer the questions based on the provided context only.
    Please provide the most accurate response based on the question
    <context>
    {context}
    <context>
    Questions: {input}
    """
)

def load_json_files(directory):
    documents = []
    for file in os.listdir(directory):
        if file.endswith('.json'):
            json_path = os.path.join(directory, file)
            with open(json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                text = json.dumps(data, ensure_ascii=False)
                documents.append(Document(page_content=text))
    return documents

def vector_embedding():
    #st.write("vector_embedding() called")
    if "vectors" not in st.session_state:
       # st.write("Initializing session state variables...")
        st.session_state.embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")
       # st.write("Embeddings initialized")
        st.session_state.docs = load_json_files("./uploaded-data-json-files")  # Data Ingestion
        st.write(f"Loaded {len(st.session_state.docs)} documents")
        st.session_state.text_splitter = RecursiveCharacterTextSplitter(chunk_size=3000, chunk_overlap=200)  # Chunk Creation
       # st.write("Text splitter initialized")
        st.session_state.final_documents = st.session_state.text_splitter.split_documents(st.session_state.docs[:4])  # Splitting
        st.write(f"Split into {len(st.session_state.final_documents)} final documents")
        st.session_state.vectors = FAISS.from_documents(st.session_state.final_documents, st.session_state.embeddings)  # Vector OpenAI embeddings
        st.write("Vector DB is Ready !!")        



def save_uploaded_files(uploaded_files, temp_folder):
    if not os.path.exists(temp_folder):
        os.makedirs(temp_folder)
    for uploaded_file in uploaded_files:
        with open(os.path.join(temp_folder, uploaded_file.name), "wb") as f:
            f.write(uploaded_file.getbuffer())
    st.success("Files uploaded successfully!")

def move_files_to_data_folder(temp_folder, data_folder):
    if not os.path.exists(data_folder):
        os.makedirs(data_folder)
    for file_name in os.listdir(temp_folder):
        src_file = os.path.join(temp_folder, file_name)
        dst_file = os.path.join(data_folder, file_name)
        if not os.path.exists(dst_file):
            os.rename(src_file, dst_file)
    #st.success("Files moved to data folder successfully!")
    # Clear the temporary folder and delete it
    for file_name in os.listdir(temp_folder):
        os.remove(os.path.join(temp_folder, file_name))
    os.rmdir(temp_folder)
    #st.success("Temporary folder deleted successfully!")


uploaded_files = st.file_uploader("Upload JSON files", type=["json"], accept_multiple_files=True)

if uploaded_files:
    temp_folder = "./temporary_folder"
    save_uploaded_files(uploaded_files, temp_folder)

if st.button("Initialize Vector Store with uploaded files"):
    temp_folder = "./temporary_folder"
    data_folder = "./uploaded-data-json-files"
    if uploaded_files:
        move_files_to_data_folder(temp_folder, data_folder)
    vector_embedding()
    # Clear uploaded files from browser memory
    uploaded_files = None

prompt1 = st.text_input("Enter Your Question From Documents")

if prompt1:
    document_chain = create_stuff_documents_chain(llm, prompt)
    retriever = st.session_state.vectors.as_retriever()
    keyword_retriever = BM25Retriever.from_documents(st.session_state.final_documents)

    keyword_retriever.k =  3
    # initialize the ensemble retriever
    ensemble_retriever = EnsembleRetriever(
        retrievers=[keyword_retriever, retriever ], weights=[0.5, 0.5]
    )
    #retrieval_chain = create_retrieval_chain(retriever, document_chain)
    retrieval_chain = create_retrieval_chain(ensemble_retriever, document_chain)
    start = time.process_time()
    response = retrieval_chain.invoke({'input': prompt1})
    st.write(response)
    st.write(f"Response time: {time.process_time() - start}")
    st.write(response['answer'])
