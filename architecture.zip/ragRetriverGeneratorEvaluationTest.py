from sklearn.metrics import precision_score, recall_score
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain.chains import create_retrieval_chain
from langchain_community.vectorstores import FAISS
from langchain_community.document_loaders import PyPDFDirectoryLoader
from langchain_google_genai import GoogleGenerativeAIEmbeddings

# Assuming `response` is the model output and `expected_answer` is the ground truth.

def evaluate_retriever(retrieved_docs, relevant_docs):
    # Context Precision
    precision = precision_score(relevant_docs, retrieved_docs, average='binary')
    
    # Context Recall
    recall = recall_score(relevant_docs, retrieved_docs, average='binary')
    
    return precision, recall

def evaluate_generator(generated_answer, ground_truth, retrieved_docs):
    # Faithfulness: Is the generated answer consistent with retrieved_docs?
    faithfulness_score = int(all(doc in generated_answer for doc in retrieved_docs))
    
    # Answer Relevancy: Does the answer directly address the question?
    relevancy_score = int(ground_truth in generated_answer)
    
    return faithfulness_score, relevancy_score

# Initialize components for RAG
llm = ChatGroq(groq_api_key=groq_api_key, model_name="Llama3-8b-8192")

def vector_embedding():
    st.session_state.embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")
    st.session_state.loader = PyPDFDirectoryLoader("./data-pdf-files")
    st.session_state.docs = st.session_state.loader.load()
    st.session_state.text_splitter = RecursiveCharacterTextSplitter(chunk_size=2000, chunk_overlap=200)
    st.session_state.final_documents = st.session_state.text_splitter.split_documents(st.session_state.docs[:20])
    st.session_state.vectors = FAISS.from_documents(st.session_state.final_documents, st.session_state.embeddings)

# Perform evaluation
retrieved_docs = ["doc1", "doc2", "doc3"]
relevant_docs = ["doc1", "doc2"]  # Ground truth for what should be relevant

precision, recall = evaluate_retriever(retrieved_docs, relevant_docs)

# Generate an answer (this would normally come from your model)
generated_answer = "Generated text based on the retrieved documents."
ground_truth = "Expected answer text."

faithfulness, relevancy = evaluate_generator(generated_answer, ground_truth, retrieved_docs)

# Display metrics
print(f"Context Precision: {precision}")
print(f"Context Recall: {recall}")
print(f"Faithfulness: {faithfulness}")
print(f"Answer Relevancy: {relevancy}")
