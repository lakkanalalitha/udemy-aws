import streamlit as st
import time
import os
import json
from langchain_groq import ChatGroq
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain.prompts import ChatPromptTemplate
from langchain.chains import create_retrieval_chain
from langchain.vectorstores import FAISS
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain.docstore.document import Document

# Load the GROQ and Google API keys
google_api_key = "AIzaSyApvKUpUh1_AKiToNVnz9Rup_Sx56S8vjU"
groq_api_key = "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"

st.title("Patent Json Document(s) Q&A")

#Llama3 model
llm = ChatGroq(groq_api_key=groq_api_key, model_name="Llama3-8b-8192")

prompt = ChatPromptTemplate.from_template( """
Task: Carefully review the patent details provided and extract relevant information such as application number, publication number, title, decision, key dates, inventor details, examiner details, patent classification, abstract, claims, summary, full description, and background.

We are particularly interested in extracting the following details:

- Application Number
- Publication Number
- Title
- Decision (e.g., ACCEPTED, REJECTED)
- Key Dates:
  - Filing Date
  - Abandonment Date
  - Date Produced
  - Date Published

- Inventor Details:
  - Last Name
  - First Name
  - City
  - Country

- Examiner Details:
  - Last Name
  - First Name

- Patent Classification:
  - Main CPC Label
  - CPC Labels (if applicable)
  - Main IPCR Label
  - IPCR Labels (if applicable)
  - USPC Class
  - USPC Subclass

- Content Details:
  - Abstract
  - Claims
  - Summary
  - Full Description (click the button to expand for more details)
  - Background

Please provide the extracted information in a structured format, ensuring accuracy and completeness.

Example: If the patent details include:
What is the title of the application? Answer: "Starting device"

What is the decision regarding the application? Answer: "REJECTED"

When was the application produced? Answer: "20050504"

When was the application published? Answer: "20050519"

What is the USPC class and subclass of the application? Answer: "074" and "006000", respectively.

Who are the inventors of the application? Answer: "Braun" and "Kugler", both from Germany.

What is the abstract of the application? Answer: "A starter device for internal combustion engines is proposed that comprises a drive mechanism and a gearing having a variable gear ratio, which said gearing is situated after the drive mechanism. The starter device is characterized by the fact that the gear ratio of the gearing is infinitely variable."

What are the claims of the application? Answer: Claim 1 states that the starter device has a drive mechanism and a gearing with a variable gear ratio, and the gear ratio is infinitely variable. The other claims (2-6) provide further specifications of the gearing and its functionality.



Your response should summarize these details concisely.
Answer the questions based on the provided context only.
Please provide the most accurate response based on the question.

<context>
{context}
<context>
Questions: {input}

"""
)

def load_json_files(directory):
    documents = []
    for file in os.listdir(directory):
        if file.endswith('.json'):
            json_path = os.path.join(directory, file)
            with open(json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                text = json.dumps(data, ensure_ascii=False)
                documents.append(Document(page_content=text))
    return documents

def vector_embedding():
    st.write("vector_embedding() called")
    if "vectors" not in st.session_state:
        st.write("Initializing session state variables...")
        st.session_state.embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")
        st.write("Embeddings initialized")
        st.session_state.docs = load_json_files("./data-json-files")  # Data Ingestion
        st.write(f"Loaded {len(st.session_state.docs)} documents")
        st.session_state.text_splitter = RecursiveCharacterTextSplitter(chunk_size=3000, chunk_overlap=200)  # Chunk Creation
        st.write("Text splitter initialized")
        st.session_state.final_documents = st.session_state.text_splitter.split_documents(st.session_state.docs[:5])  # Splitting
        st.write(f"Split into {len(st.session_state.final_documents)} final documents")
        st.session_state.vectors = FAISS.from_documents(st.session_state.final_documents, st.session_state.embeddings)  # Vector OpenAI embeddings
        st.write("Vector embeddings created and stored in session state")


prompt1 = st.text_input("Enter Your Question From Documents")

if st.button("Search"):
    vector_embedding()
    st.write("==================================================================")
    st.write("Vector Store DB Is Ready")

if prompt1:
    document_chain = create_stuff_documents_chain(llm, prompt)
    retriever = st.session_state.vectors.as_retriever()
    retrieval_chain = create_retrieval_chain(retriever, document_chain)
    start = time.process_time()
    response = retrieval_chain.invoke({'input': prompt1})
    st.write(f"Response time: {time.process_time() - start}")
    st.write(response['answer'])


    # # With a Streamlit expander
    # with st.expander("Document Similarity Search"):
    #     # Find the relevant chunks
    #     for i, doc in enumerate(response["context"]):
    #         st.write(doc.page_content)
    #         st.write("--------------------------------")
