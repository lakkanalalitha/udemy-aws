import streamlit as st
import time
from langchain_groq import ChatGroq
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_core.prompts import ChatPromptTemplate
from langchain.chains import create_retrieval_chain
from langchain_community.vectorstores import FAISS
from langchain_community.document_loaders import PyPDFDirectoryLoader
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
from rouge_score import rouge_scorer

# Initialize Streamlit app title
st.title("Patent PDF Document Q&A")

# Initialize ChatGroq with API key and model name
groq_api_key = "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"
llm = ChatGroq(groq_api_key=groq_api_key, model_name="Llama3-8b-8192")

# Define a chat prompt template
prompt = ChatPromptTemplate.from_template(
    """
    Answer the questions based on the provided context only.
    Please provide the most accurate response based on the question
    <context>
    {context}
    <context>
    Questions:{input}
    """
)

# Initialize session state variables
if "qna_history" not in st.session_state:
    st.session_state.qna_history = []
if "reference_responses" not in st.session_state:
    st.session_state.reference_responses = []  # For storing reference responses

# Function to initialize vector embeddings and document retrieval
def vector_embedding():
    if "vectors" not in st.session_state:
        st.session_state.embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")
        st.session_state.loader = PyPDFDirectoryLoader("./data-pdf-files")  # Data Ingestion
        st.session_state.docs = st.session_state.loader.load()  # Document Loading
        st.session_state.text_splitter = RecursiveCharacterTextSplitter(chunk_size=2000, chunk_overlap=200)  # Chunk Creation
        st.session_state.final_documents = st.session_state.text_splitter.split_documents(st.session_state.docs[:20])  # Splitting
        st.session_state.vectors = FAISS.from_documents(st.session_state.final_documents, st.session_state.embeddings)  # Vector OpenAI embeddings

# BLEU score calculation
def calculate_bleu(reference, response):
    reference_tokens = [reference.split()]
    response_tokens = response.split()
    smoothing_function = SmoothingFunction().method1
    score = sentence_bleu(reference_tokens, response_tokens, smoothing_function=smoothing_function)
    return score

# ROUGE score calculation
def calculate_rouge(reference, response):
    scorer = rouge_scorer.RougeScorer(['rouge1', 'rougeL'], use_stemmer=True)
    scores = scorer.score(reference, response)
    return scores

# Text input for user question
prompt1 = st.text_input("Enter Your Question From Documents")

# Text input for reference answer (for evaluation purposes)
reference_answer = st.text_input("Enter Reference Answer (For Evaluation)")

# Button to trigger vector embedding and document retrieval
if st.button("Search"):
    vector_embedding()
    st.write("Vector Store DB Is Ready")

# Perform question answering if a question is provided
if prompt1:
    document_chain = create_stuff_documents_chain(llm, prompt)
    retriever = st.session_state.vectors.as_retriever()
    retrieval_chain = create_retrieval_chain(retriever, document_chain)
    start = time.process_time()
    response = retrieval_chain.invoke({'input': prompt1})
    processing_time = time.process_time() - start
    st.write(response['answer'])

    # Store question, answer, and reference in session state history
    st.session_state.qna_history.append({
        "question": prompt1,
        "answer": response['answer'],
        "reference": reference_answer,
        "processing_time": processing_time
    })

    # Display history of previous questions and answers
    st.write("==================================================================")
    st.write("Previous Q&A History:")
    st.write("==================================================================")
    for idx, qa_pair in enumerate(st.session_state.qna_history):
        st.write(f"Question {idx + 1}: {qa_pair['question']}")
        st.write(f"Answer {idx + 1}: {qa_pair['answer']}")
        st.write(f"Reference {idx + 1}: {qa_pair['reference']}")
        st.write(f"Processing Time {idx + 1}: {qa_pair['processing_time']} seconds")

        # Calculate and display BLEU and ROUGE scores
        if qa_pair['reference']:
            bleu_score = calculate_bleu(qa_pair['reference'], qa_pair['answer'])
            rouge_score = calculate_rouge(qa_pair['reference'], qa_pair['answer'])

            st.write(f"  BLEU Score: {bleu_score:.4f}")
            st.write(f"  ROUGE-1: {rouge_score['rouge1'].fmeasure:.4f}")
            st.write(f"  ROUGE-L: {rouge_score['rougeL'].fmeasure:.4f}")
        st.write("--------------------------------")
