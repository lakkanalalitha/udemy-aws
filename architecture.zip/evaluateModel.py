import streamlit as st
from sklearn.metrics import precision_score, recall_score, f1_score
from langchain_groq import ChatGroq
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_core.prompts import ChatPromptTemplate
from langchain.chains import create_retrieval_chain
from langchain_community.vectorstores import FAISS
from langchain_community.document_loaders import PyPDFDirectoryLoader
from langchain_google_genai import GoogleGenerativeAIEmbeddings

# Sample ground truth
ground_truth = {
    "What is the title of the patent?": "Title: Sample Patent Title",
    "Who is the inventor?": "Inventor: John Doe",
    # Add more questions and answers here
}

# Initialize Streamlit app title
st.title("Evaluate Patent PDF Document Q&A")

# Initialize ChatGroq with API key and model name
groq_api_key = "your_groq_api_key"
llm = ChatGroq(groq_api_key=groq_api_key, model_name="Llama3-8b-8192")

# Define a chat prompt template
prompt = ChatPromptTemplate.from_template(
    """
    Answer the questions based on the provided context only.
    Please provide the most accurate response based on the question.
    <context>
    {context}
    <context>
    Questions:{input}
    """
)

# Initialize session state variables
if "qna_history" not in st.session_state:
    st.session_state.qna_history = []

# Function to initialize vector embeddings and document retrieval
def vector_embedding():
    if "vectors" not in st.session_state:
        st.session_state.embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")
        st.session_state.loader = PyPDFDirectoryLoader("./data-pdf-files")
        st.session_state.docs = st.session_state.loader.load()
        st.session_state.text_splitter = RecursiveCharacterTextSplitter(chunk_size=2000, chunk_overlap=200)
        st.session_state.final_documents = st.session_state.text_splitter.split_documents(st.session_state.docs[:20])
        st.session_state.vectors = FAISS.from_documents(st.session_state.final_documents, st.session_state.embeddings)

# Evaluate precision, recall, and F1-score
def evaluate_responses(ground_truth, generated_responses):
    y_true = []
    y_pred = []
    
    for question, true_answer in ground_truth.items():
        generated_answer = generated_responses.get(question, "")
        y_true.append(true_answer)
        y_pred.append(generated_answer)
    
    # Convert to binary relevance (relevant = 1, non-relevant = 0)
    y_true_binary = [1 if ans.strip().lower() in generated_responses[question].strip().lower() else 0 for question, ans in ground_truth.items()]
    y_pred_binary = [1] * len(y_pred)  # Assuming all generated responses are relevant (for simplicity)
    
    precision = precision_score(y_true_binary, y_pred_binary, average='binary')
    recall = recall_score(y_true_binary, y_pred_binary, average='binary')
    f1 = f1_score(y_true_binary, y_pred_binary, average='binary')
    
    return precision, recall, f1

# Text input for user question
prompt1 = st.text_input("Enter Your Question From Documents")

# Button to trigger vector embedding and document retrieval
if st.button("Search"):
    vector_embedding()
    st.write("Vector Store DB Is Ready")

# Perform question answering if a question is provided
if prompt1:
    document_chain = create_stuff_documents_chain(llm, prompt)
    retriever = st.session_state.vectors.as_retriever()
    retrieval_chain = create_retrieval_chain(retriever, document_chain)
    response = retrieval_chain.invoke({'input': prompt1})
    st.write(response['answer'])
    
    st.session_state.qna_history.append({"question": prompt1, "answer": response['answer']})

    # Run evaluation
    precision, recall, f1 = evaluate_responses(ground_truth, {prompt1: response['answer']})
    st.write(f"Precision: {precision}, Recall: {recall}, F1-Score: {f1}")

    # Display history of previous questions and answers
    st.write("Previous Q&A History:")
    for idx, qa_pair in enumerate(st.session_state.qna_history):
        st.write(f"Question {idx + 1}: {qa_pair['question']}")
        st.write(f"Answer {idx + 1}: {qa_pair['answer']}")
