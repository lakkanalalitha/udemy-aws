import nltk
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
from rouge_score import rouge_scorer

# Sample chatbot responses and reference responses
chatbot_responses = [
    "I am happy to help you.",
    "The capital of France is Paris.",
    "I don't have the answer to that question."
]

reference_responses = [
    "I'm happy to assist you.",
    "Paris is the capital of France.",
    "I am not sure about that."
]

# Initialize BLEU score calculation
def calculate_bleu(reference, response):
    reference_tokens = [reference.split()]
    response_tokens = response.split()
    smoothing_function = SmoothingFunction().method1
    score = sentence_bleu(reference_tokens, response_tokens, smoothing_function=smoothing_function)
    return score

# Initialize ROUGE score calculation
def calculate_rouge(reference, response):
    scorer = rouge_scorer.RougeScorer(['rouge1', 'rougeL'], use_stemmer=True)
    scores = scorer.score(reference, response)
    return scores

# Evaluate chatbot responses
bleu_scores = []
rouge_scores = []

for ref, res in zip(reference_responses, chatbot_responses):
    bleu_score = calculate_bleu(ref, res)
    rouge_score = calculate_rouge(ref, res)

    bleu_scores.append(bleu_score)
    rouge_scores.append(rouge_score)

# Print evaluation results
for i, (bleu, rouge) in enumerate(zip(bleu_scores, rouge_scores)):
    print(f"Response {i+1}:")
    print(f"  BLEU Score: {bleu:.4f}")
    print(f"  ROUGE-1: {rouge['rouge1'].fmeasure:.4f}")
    print(f"  ROUGE-L: {rouge['rougeL'].fmeasure:.4f}")
    print()

'''
Response 1:
  BLEU Score: 0.7598
  ROUGE-1: 0.8333
  ROUGE-L: 0.8333

Response 2:
  BLEU Score: 1.0000
  ROUGE-1: 1.0000
  ROUGE-L: 1.0000

Response 3:
  BLEU Score: 0.3679
  ROUGE-1: 0.6667
  ROUGE-L: 0.6667

'''